#ifndef MAIN_H
#define MAIN_H

#include "lexico.h"
#include "sintatico.h"

#endif
