#ifndef _LEXICO_H_
#define _LEXICO_H_

int get_token();

char* get_ultimo_token_lido();

char get_ultimo_caractere_lido();

int leu_quebra_linha();

void reset_quebra_linha();

#endif